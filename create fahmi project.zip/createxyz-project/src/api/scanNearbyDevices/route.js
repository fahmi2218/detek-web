function handler() {
  // Data perangkat yang mungkin terdeteksi
  const deviceData = [
    {
      brand: "Samsung",
      models: ["Galaxy S23", "Galaxy A54", "Galaxy M34", "Galaxy Tab S9"],
    },
    {
      brand: "Apple",
      models: ["iPhone 15", "iPhone 14", "iPad Pro", "MacBook Air"],
    },
    {
      brand: "Xiaomi",
      models: ["Redmi Note 12", "POCO F5", "Mi 13", "Mi Pad 6"],
    },
    { brand: "OPPO", models: ["Reno10", "Find N3", "A78", "Pad 2"] },
    { brand: "Vivo", models: ["V29", "Y27", "X90", "Pad 2"] },
    { brand: "realme", models: ["11 Pro", "C55", "Pad 2", "Watch 3"] },
    {
      brand: "ASUS",
      models: ["ROG Phone 7", "Zenfone 10", "Vivobook", "ZenBook"],
    },
    { brand: "OnePlus", models: ["11", "Nord CE 3", "Pad", "Watch 2"] },
    {
      brand: "Nothing",
      models: ["Phone 2", "Phone 1", "Ear 2", "CMF Watch Pro"],
    },
    {
      brand: "Google",
      models: ["Pixel 8", "Pixel 7a", "Pixel Tablet", "Pixel Watch 2"],
    },
  ];

  const numberOfDevices = Math.floor(Math.random() * 5) + 2; // 2-6 perangkat
  const devices = [];

  for (let i = 0; i < numberOfDevices; i++) {
    // Pilih brand dan model secara acak
    const brandData = deviceData[Math.floor(Math.random() * deviceData.length)];
    const model =
      brandData.models[Math.floor(Math.random() * brandData.models.length)];

    // Jarak: 0.5 - 8 meter (fokus pada jangkauan Bluetooth yang efektif)
    const distance = +(0.5 + Math.random() * 7.5).toFixed(1);
    const angle = Math.random() * Math.PI * 2;
    // Sesuaikan radius untuk visualisasi
    const radius = (distance / 8) * 50; // Menggunakan 8m sebagai jarak maksimal untuk scaling

    devices.push({
      id: `device-${i}`,
      name: `${brandData.brand} ${model}`,
      brand: brandData.brand,
      model: model,
      distance,
      position: {
        x: Math.cos(angle) * radius,
        y: Math.sin(angle) * radius,
      },
      // Kekuatan sinyal berdasarkan jarak
      signalStrength: Math.max(
        0,
        Math.min(100, Math.round(100 - distance * 15))
      ),
    });
  }

  return { devices };
}
export async function POST(request) {
  return handler(await request.json());
}